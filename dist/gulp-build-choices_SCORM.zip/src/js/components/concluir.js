export default{name:"Concluir",template:`
    <div id="concluir" class="my-12 scrollspy flex--justify-center">
      <a href="#/" id="finishButton" class="btn-large filled waves-effect waves-light">Concluir
        <span class="ml-1 pb-1 material-symbols-rounded"> check </span>
      </a>
    </div>
    `};