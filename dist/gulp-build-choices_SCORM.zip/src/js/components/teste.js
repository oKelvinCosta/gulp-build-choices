export default{setup(){return onMounted(()=>{console.log("kelvin")}),{}},template:`
      <h1>KELVIN</h1>
    `};