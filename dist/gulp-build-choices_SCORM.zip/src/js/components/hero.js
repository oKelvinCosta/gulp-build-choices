export default{name:"Hero",template:`
    <div id="hero" class="scrollspy">
    <div class="container--medium">
      <div class="display1 center-align green-text">
        O que tem em cada alimento?
      </div>
    </div>
  </div>
    `};